package com.tka.controller;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.tka.Entity.UserLogin;


@Controller
public class RegistraControl {
	@Autowired
	SessionFactory factory;

@RequestMapping("saveToDB")
public String saveToDB( UserLogin user) {
	
	Session session= factory.openSession();
	Transaction tx=session.beginTransaction();
	
	session.save(user);
	
	tx.commit();
	return "login";
}

@RequestMapping("register")

public String register()
{
	return "register";
}


@RequestMapping("welcome")

public String welcome()
{
	return "welcome";
}

}
