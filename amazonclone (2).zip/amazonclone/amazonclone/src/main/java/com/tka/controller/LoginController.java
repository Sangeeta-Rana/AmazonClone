package com.tka.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.tka.Entity.UserLogin;
import com.tka.service.Serviceclass;



@Controller
public class LoginController {
	@Autowired
   Serviceclass serviceclass;
    
    

@RequestMapping("validate")
public ModelAndView validate (UserLogin user) {
	 
	String webpage=" ";
	String data =" ";
	
	boolean answer=serviceclass .validate(user.getUsername(), user.getPassword());
	
	ModelAndView modelAndView= new ModelAndView();
	
	if(answer) {
		
		webpage="welcome";
		data=" Happy to see you again, "+ user.getUsername();
	}
	else {
		webpage="login";
		data="Wrong credentials" ;
		
	}
	


	modelAndView.setViewName(webpage);
	modelAndView.addObject("message",data);
return modelAndView;

}

@RequestMapping("login")
public String  login () {
	
	return "login";
}}





	
	

