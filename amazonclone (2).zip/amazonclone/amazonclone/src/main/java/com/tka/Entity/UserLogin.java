package com.tka.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class UserLogin {
@Id
	String username;
	int mobno;
	String password;
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public int getMobno() {
		return mobno;
	}
	public void setMobno(int mobno) {
		this.mobno = mobno;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return "UserLogin [username=" + username + ", password=" + password + ", mobno=" + mobno + "]";
	}
}
