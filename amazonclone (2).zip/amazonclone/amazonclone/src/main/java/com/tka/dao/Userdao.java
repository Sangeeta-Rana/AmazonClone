package com.tka.dao;



import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.tka.Entity.UserLogin;


@Repository
public class Userdao {



	@Autowired
	SessionFactory factory;
	public  String getDataBasePassword (String username) {
		
		Session session = factory.openSession();
		UserLogin	userfromdb=session.get(UserLogin.class,username);
		return userfromdb.getPassword();
	}
	
	

}





