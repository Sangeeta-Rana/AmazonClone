package com.tka.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tka.dao.Userdao;
@Service


public class Serviceclass {

	@Autowired
	Userdao dao;
	
public boolean validate (String namefromBrowser, String password) {
		
		String databasepassword=dao.getDataBasePassword(namefromBrowser);
		if(databasepassword.equals(password)) {
			return true;
		}
		else {
			return false;

		}


	
	
	
}
}